package apt.hthang.doctruyenonline.projections;

/**
 * @author Đời Không Như Là Mơ on 21/11/2018
 * @project truyenonline
 */
public interface CategorySummary {

    Integer getId();

    String getName();

    String getMetatitle();

    Integer getStatus();
}
