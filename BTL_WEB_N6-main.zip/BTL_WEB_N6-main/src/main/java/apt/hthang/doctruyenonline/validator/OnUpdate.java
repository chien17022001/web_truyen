package apt.hthang.doctruyenonline.validator;

import javax.validation.groups.Default;

/**
 * @author Đời Không Như Là Mơ
 * @project doctruyenonline
 */
public interface OnUpdate extends Default {

}
